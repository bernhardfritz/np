package exercise1;

public interface Event {
	public String getMessage();
}