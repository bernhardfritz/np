package exercise1;

public interface EventListener {
	
	public void onEvent(Event e);
	
	public String getName();
}