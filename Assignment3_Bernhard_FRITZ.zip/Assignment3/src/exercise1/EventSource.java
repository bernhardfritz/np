package exercise1;

public interface EventSource {
	void registerListener(EventListener e);
}