package exercise3;

public class ThreadStateMain {

	public static void main(String[] args) {
		new MyMonitoringThread("Monitoring").start();
	}
}